function openProject(url) {
  window.open(url, "_blank");
}
